# Happy Birthday Tumi — Diki Suhendra

Python terminal animation based on the original ASCII birthday script.

- Large multi-line ASCII lettering
- `DIKI SUHENDRA` replaces the original name
- Characters appear one by one
- No external packages required

Run:

```bash
python happy_birthday_diki.py
```
